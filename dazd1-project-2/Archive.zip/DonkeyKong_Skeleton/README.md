# **SWEN20003 Project 2B - Shadow Donkey Kong**

## **📌 Project Overview**
This is an implementation of **Shadow Donkey Kong** for SWEN20003 Project 2B. The game is a classic platformer featuring two levels where Mario must navigate obstacles, collect weapons, and defeat Donkey Kong. This implementation follows object-oriented design principles with proper inheritance hierarchies, encapsulation, and low coupling.

---

## **🎮 Game Features**

### **Level 1: Classic Platforming**
- Navigate platforms and ladders to reach Donkey Kong
- Collect hammer to defeat barrels and Donkey Kong
- Jump over barrels for bonus points
- Win by reaching Donkey Kong with a hammer

### **Level 2: Advanced Combat**
- New entities: Normal Monkeys, Intelligent Monkeys, Blasters, Bullets, Bananas
- Collect blasters to shoot bullets at Donkey Kong and monkeys
- Avoid intelligent monkeys that shoot bananas every 5 seconds
- Win by shooting Donkey Kong 5 times or touching him with a hammer
- Donkey Kong has a health system (5 health points)

### **Scoring System**
- Destroying barrels: 100 points
- Jumping over barrels: 30 points
- Destroying monkeys: 100 points
- Time bonus: 3 × remaining seconds (applied per level)
- Score carries over from Level 1 to Level 2

---

## **🏗️ Architecture & Design Decisions**

### **Inheritance Structure**
Following the forum requirement that inheritance must be used in Project 2B, the implementation includes:

#### **Entity Hierarchy**
- **Entity** (abstract base class) → All game objects inherit from this
- **Monkey** (abstract class) → **NormalMonkey**, **IntelligentMonkey**
- **Projectile** (abstract class) → **Bullet**, **Banana**

#### **Screen Management**
- **Screen** (abstract base class) → **TitleScreen**, **GameplayScreen**, **GameOverScreen**
- **GameplayScreen** (abstract class) → **Level1Screen**, **Level2Screen**

### **Interface Implementation**
The project uses interfaces to define common behaviors:
- **Collidable** - for collision detection
- **Movable** - for entities that can move
- **Weapon** - for collectible weapons
- **Destroyable** - for entities that can be destroyed

### **Encapsulation Principles**
- All attributes are **private** (no protected attributes as per forum guidelines)
- Public getter/setter methods provide controlled access
- Each class has a single, well-defined responsibility

---

## **📋 Implementation Assumptions**

### **Game Mechanics Assumptions**

#### **1. Level Transition & Scoring**
- **Timer resets for each level** (as permitted in forum post #455)
- **Level 1 base score carries over to Level 2** (no time bonus awarded in Level 1)
- **Only Level 2 awards time bonus** (3 × remaining seconds) upon completion
- **Death results in final score of 0** (different from Project 1 implementation)

#### **2. Weapon System**
- **Hammer and blaster are mutually exclusive** - collecting one weapon replaces the other
- **Replaced weapons disappear** from the screen (as clarified in forum post #543)
- **Bullet count accumulates when collecting multiple blasters** (sum of current + new blaster bullets)
- **Mario reverts to normal appearance when bullets are depleted** (as specified in requirements)

#### **3. Monkey Behavior**
- **Monkeys turn around at platform edges** and do not fall off platforms
- **Remaining patrol distance is lost** when hitting platform edge (realistic movement)
- **Intelligent monkeys shoot bananas every 5 seconds** starting from creation time
- **Monkeys are destroyed by both hammer Mario and bullets**
- **Banana persistence after monkey death**: When an intelligent monkey is destroyed, any bananas it has already fired continue flying until they expire naturally (300 pixels) or hit a collision target. This design choice prioritizes consistency in projectile physics over immediate cleanup.

#### **4. Projectile Physics**
- **Bullets and bananas are not affected by gravity** (horizontal movement only)
- **Maximum travel distance is 300 pixels** before disappearing
- **Bullets disappear when hitting platforms or screen boundaries**
- **Bananas cannot be destroyed by hammer Mario** (as clarified in forum post #460)

#### **5. Barrel Jump Scoring**
- **Enhanced global jump cooldown mechanism** prevents duplicate scoring when jumping over multiple adjacent barrels
- **45-frame global cooldown** (increased from 15) after any barrel jump score to prevent the same jump being counted multiple times
- **Individual barrel cooldowns** (30 frames) prevent repeated scoring on the same barrel
- **Y-position tracking** ensures different jumps at different heights are properly distinguished
- **Vertical distance limitation** (80 pixels maximum) prevents cross-layer jump scoring - Mario can only score points for barrels in the same vertical layer, eliminating the bug where jumping on top level could trigger scoring for barrels on lower levels
- **Ladder-aware reset logic** prevents state corruption when jumping near ladders (fixes middle barrel duplicate scoring issue)
- **Jump-in-progress tracking** prevents premature reset of jump states during complex movements
- **Enhanced validation** includes velocity checks and position verification for stricter scoring conditions

#### **6. Entity Placement & Gravity**
- **Barrel physics clarification** - Section 2.3.2 specifies "initial downward velocity of 0.4" while Section 4 specifies "gravity = 0.2"
- **Implementation assumption**: These are separate physics concepts - barrels start with 0.4 initial velocity and then apply 0.2 gravity acceleration each frame
- **Justification**: This interpretation treats initial velocity and gravity acceleration as distinct parameters, which is physically accurate
- **Ladders may or may not be affected by gravity** (assumption documented as per forum post #547)
- **Initial entity positioning correction** - entities overlapping platforms are immediately placed on top
- **Platform collision uses center-based positioning** for consistent behavior

#### **7. User Interface**
- **Title screen text is center-aligned** for better visual presentation
- **Score and time display at coordinates from app.properties** (50, 50) and (50, 80) respectively
- **Donkey Kong health and bullet count displayed in Level 2** using gamePlay.score.fontSize

### **Technical Implementation Assumptions**

#### **1. File Loading**
- **Image file paths can be hardcoded within entity classes** (as permitted in forum post #523)
- **Properties files are not modified** except for potential frame rate adjustments
- **Error handling assumes valid property file format** with graceful defaults where possible

#### **2. Performance Considerations**
- **Bullet boundary checking is implementation-dependent** (as noted in forum post #501)
- **Off-screen bullets are cleaned up at 300-pixel limit** rather than immediate boundary checking
- **Entity lists are managed efficiently** to prevent memory leaks

#### **3. Input Handling**
- **Level selection works from title screen** (Enter for Level 1, '2' key for Level 2)
- **Shooting with 'S' key works in all player states** (standing, climbing, jumping)
- **No input buffering** - single key press per action

---

## **🎯 Key Design Patterns Used**

### **Strategy Pattern**
- Different screen types implement different update and draw behaviors
- Level-specific gameplay logic encapsulated in Level1Screen and Level2Screen

### **Factory Pattern**
- Entity creation based on property file configuration
- Dynamic loading of level-specific entities

### **Observer Pattern**
- Score management system updates based on game events
- State transitions trigger appropriate screen changes


### **Controls**
- **Arrow Keys**: Move Mario (left/right on platforms, up/down on ladders)
- **Space**: Jump
- **S**: Shoot bullet (when holding blaster)
- **Enter**: Start Level 1 (from title screen)
- **2**: Start Level 2 directly (from title screen)
- **ESC**: Quit game

